# Figure 1 source snapshot

The full-width and single-column figures use dark-purple ADM boxes and titles.
Install requirements.txt, then run from this directory:

```sh
python fig/plot_figure1_applications.py --right-legend --no-phase-headers
python fig/plot_figure1_single_column.py
```

Exports are written beside the scripts using their original paper filenames.
The full-width stem is figure1_applications_bordered_redesign_swapped_simple_bands_right_legend_no_headers.
The single-column stem is figure1_single_column.
The bundle contains the aggregate inputs, the paper's Table 7 snapshot, browser example image,
plotting helpers, shared paper typography, and licensed Albert Sans fonts.
No browser or experiment service is required. Probabilities and teacher choices in the
diagram are illustrative; quantitative results use the frozen aggregate inputs.
